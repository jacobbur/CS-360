package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText username, password;
    Button login, register;
    DBHelper DB;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

            username = (EditText) findViewById(R.id.username);
            password = (EditText) findViewById(R.id.password);
            login = (Button) findViewById(R.id.login);
            register = (Button) findViewById(R.id.register);
            DB = new DBHelper(this);

            register.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String user = username.getText().toString();
                    String pass = password.getText().toString();

                    if(user.equals("")||pass.equals(""))
                        Toast.makeText(MainActivity.this, "Please enter required fields", Toast.LENGTH_SHORT);
                    else{
                        Boolean checkuser = DB.checkusername(user);
                        if(checkuser==false) {
                            Boolean insert = DB.insertData(user, pass);
                            if(insert==true) {
                                Toast.makeText(MainActivity.this, "Registration successful!", Toast.LENGTH_SHORT);
                                Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                                startActivity(intent);
                            }else {
                                Toast.makeText(MainActivity.this, "Registration unsuccessful", Toast.LENGTH_SHORT);
                            }
                        }
                        else{
                            Toast.makeText(MainActivity.this, "User already exists! Please try again.",Toast.LENGTH_SHORT);
                        }
                    }

                }
            });

            login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    String user = username.getText().toString();
                    String pass = password.getText().toString();

                    if(user.equals("")||pass.equals(""))
                        Toast.makeText(MainActivity.this, "Please enter required fields", Toast.LENGTH_SHORT);
                    else {
                        Boolean checkuserpass = DB.checkusernamepassword(user, pass);
                        if (checkuserpass == true) {
                            Toast.makeText(MainActivity.this, "Login successful!", Toast.LENGTH_SHORT);
                            Intent intent = new Intent(getApplicationContext(), SMS.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(MainActivity.this, "Login failed! Please try again!", Toast.LENGTH_SHORT);
                        }
                    }
                }
            });
    }
}